document.getElementById('logo').innerHTML = "Recipes"

const footer = document.getElementById('footer')
footer.style.color = "white";
footer.style.width = "80%";
footer.style.borderTopLeftRadius = "1rem";
footer.style.borderTopRightRadius = "1rem";
footer.style.textAlign = "center";
footer.style.backgroundColor = "rgba(25, 135, 84, 1)";
footer.style.marginLeft = "auto";
footer.style.marginRight = "auto";
footer.style.paddingTop = "1rem";
footer.style.paddingBottom = "1rem";